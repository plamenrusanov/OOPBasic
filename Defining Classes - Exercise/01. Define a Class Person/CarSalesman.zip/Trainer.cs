﻿using System;
using System.Collections.Generic;
using System.Text;


public class Trainer
{
    private string name;
    private int numberOfBadges;
    private List<Pokemon> pokemons;
    
   

    public Trainer(string trainer, string pokName, string pokElement, int pokHealt, int numberOFBadges = 0)
    {
        this.Name = trainer;
        this.Pokemons = new List<Pokemon>();
        Pokemon p = new Pokemon(pokName, pokElement, pokHealt);
        Pokemons.Add(p);
        this.NumberOfBadges = numberOFBadges;
    }

    public List<Pokemon> Pokemons
    {
        get { return pokemons; }
        set { pokemons = value; }
    }


    public int NumberOfBadges
    {
        get { return numberOfBadges; }
        set { numberOfBadges = value; }
    }

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

}

