﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P04_Hospital
{
    public class Program
    {
        public static void Main()
        {
            List<Doctor> doctors = new List<Doctor>();
            List<Departments> departments = new List<Departments>();
            AddPatients(doctors, departments);
            
            DisplayConditions(doctors, departments);
            
          /*  Dictionary<string, List<string>> doktori = new Dictionary<string, List<string>>();
            Dictionary<string, List<List<string>>> departments = new Dictionary<string, List<List<string>>>();


            string command = Console.ReadLine();
            while (command != "Output")
            {
                string[] jetoni = command.Split();
                var departament = jetoni[0];
                var purvoIme = jetoni[1];
                var vtoroIme = jetoni[2];
                var pacient = jetoni[3];
                var cqloIme = purvoIme + vtoroIme;

                if (!doktori.ContainsKey(purvoIme + vtoroIme))
                {
                    doktori[cqloIme] = new List<string>();
                }
                if (!departments.ContainsKey(departament))
                {
                    departments[departament] = new List<List<string>>();
                    for (int stai = 0; stai < 20; stai++)
                    {
                        departments[departament].Add(new List<string>());
                    }
                }

                bool imaMqsto = departments[departament].SelectMany(x => x).Count() < 60;
                if (imaMqsto)
                {
                    int staq = 0;
                    doktori[cqloIme].Add(pacient);
                    for (int st = 0; st < departments[departament].Count; st++)
                    {
                        if (departments[departament][st].Count < 3)
                        {
                            staq = st;
                            break;
                        }
                    }
                    departments[departament][staq].Add(pacient);
                }

                command = Console.ReadLine();
            }

            command = Console.ReadLine();

            while (command != "End")
            {
                string[] args = command.Split();

                if (args.Length == 1)
                {
                    Console.WriteLine(string.Join("\n", departments[args[0]].Where(x => x.Count > 0).SelectMany(x => x)));
                }
                else if (args.Length == 2 && int.TryParse(args[1], out int staq))
                {
                    Console.WriteLine(string.Join("\n", departments[args[0]][staq - 1].OrderBy(x => x)));
                }
                else
                {
                    Console.WriteLine(string.Join("\n", doktori[args[0] + args[1]].OrderBy(x => x)));
                }
                command = Console.ReadLine();
            }*/
        }

        private static void AddPatients(List<Doctor> doctors, List<Departments> departments)
        {
            string input;
            while ((input = Console.ReadLine()) != "Output")
            {
                string[] patientData = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                string docName = $"{patientData[1]} {patientData[2]}";
                Doctor doctor = doctors.FirstOrDefault(d => d.Name == docName);
                if (doctor == null)
                {
                    doctor = new Doctor(patientData);
                    doctors.Add(doctor);
                }
                else
                {
                    doctor.Patients.Add(patientData[3]);
                }
                Departments department = departments.FirstOrDefault(d => d.Name == patientData[0]);
                if (department == null)
                {
                    department = new Departments(patientData);
                    departments.Add(department);
                }
                else
                {
                    department.AddPatient(patientData[3]);
                }
            }
        }

        private static void DisplayConditions(List<Doctor> doctors, List<Departments> departments)
        {
            string input;
            while ((input = Console.ReadLine()) != "End")
            {
                string[] printArguments = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);


                if (printArguments.Length == 1)
                {
                    Departments department = departments.FirstOrDefault(d => d.Name == printArguments[0]);
                    department.PrintDepartment();
                }
                else
                {
                    int room = -1;
                    bool isParse = int.TryParse(printArguments[1], out room);
                    if (isParse)
                    {
                        Departments department = departments.FirstOrDefault(d => d.Name == printArguments[0]);
                        department.PrintRoom(room);
                    }
                    else
                    {
                        string docName = $"{printArguments[0]} {printArguments[1]}";
                        Doctor doctor = doctors.FirstOrDefault(d => d.Name == docName);
                        Console.WriteLine(string.Join(Environment.NewLine, doctor.Patients.OrderBy(p => p)));
                    }
                }
            }

        }
    }
}
