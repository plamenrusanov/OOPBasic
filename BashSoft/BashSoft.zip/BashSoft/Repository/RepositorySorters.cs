﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BashSoft
{
    public static class RepositorySorters
    {
        public static void OrderAndTake(Dictionary<string, List<int>> wantedData, string comparison, int studentsToTake)
        {
            comparison = comparison.ToLower();
            if (comparison == "ascending")
            {
                PrintStudents(wantedData.OrderBy(x => x.Value.Sum())
                    .Take(studentsToTake)
                    .ToDictionary(pear => pear.Key, pear => pear.Value));
            }
            else if (comparison == "descending")
            {
                PrintStudents(wantedData.OrderByDescending(x => x.Value.Sum())
                    .Take(studentsToTake)
                    .ToDictionary(pear => pear.Key, pear => pear.Value));
            }
            else
            {
                OutputWriter.DisplayException(ExceptionMessages.InvalidStudentFilter);
            }
        }

        private static void PrintStudents (Dictionary<string, List<int>> sortedStudents)
        {
            foreach (var item in sortedStudents)
            {
                StudentsRepository.PrintStudent(item);
            }
        }

       // private static int CompareInOrder(KeyValuePair<string, List<int>> firstValue, //KeyValuePair<string, List<int>> secondValue)
       // {
       //     int totalFirst = 0;
       //     foreach (var mark in firstValue.Value)
       //     {
       //         totalFirst += mark;
       //     }
       //
       //     int totalSecond = 0;
       //     foreach (var mark in secondValue.Value)
       //     {
       //         totalSecond += mark;
       //     }
       //     return totalSecond.CompareTo(totalFirst);
       // }
       //
       // private static int CompareDescendingOrder(KeyValuePair<string, List<int>> firstValue, //KeyValuePair<string, List<int>> secondValue)
       // {
       //     int totalFirst = 0;
       //     foreach (var mark in firstValue.Value)
       //     {
       //         totalFirst += mark;
       //     }
       //
       //     int totalSecond = 0;
       //     foreach (var mark in secondValue.Value)
       //     {
       //         totalSecond += mark;
       //     }
       //     return totalFirst.CompareTo(totalSecond);
       // }
       //
       // private static Dictionary<string, List<int>> GetSortedStudents(Dictionary<string, List<int>>studentsWanted, int takeCount, Func<KeyValuePair<string, List<int>>, KeyValuePair<string, List<int>>, int> Comparison)
       // {
       //     int valuesTaken = 0;
       //     Dictionary<string, List<int>> studentSorted = new Dictionary<string, List<int>>();
       //     KeyValuePair<string, List<int>> nextInOrder = new KeyValuePair<string, List<int>>();
       //     bool isSorted = false;
       //     while (valuesTaken < takeCount)
       //     {
       //         isSorted = true;
       //         foreach (var studentWhitScore in studentSorted)
       //         {
       //             if (!string.IsNullOrEmpty(nextInOrder.Key))
       //             {
       //                 int comparisonResult = Comparison(studentWhitScore, nextInOrder);
       //                 if (comparisonResult >= 0 && !studentSorted.ContainsKey/(studentWhitScore.Key))
       //                 {
       //                     nextInOrder = studentWhitScore;
       //                     isSorted = false;
       //                 }
       //             }
       //             else
       //             {
       //                 if (!studentSorted.ContainsKey(studentWhitScore.Key))
       //                 {
       //                     nextInOrder = studentWhitScore;
       //                     isSorted = false;
       //                 }
       //             }
       //         }
       //         if (!isSorted)
       //         {
       //             studentSorted.Add(nextInOrder.Key, nextInOrder.Value);
       //             valuesTaken++;
       //             nextInOrder = new KeyValuePair<string, List<int>>();
       //         }
       //     }
       //
       //     return studentSorted;
       // }
    }
}
