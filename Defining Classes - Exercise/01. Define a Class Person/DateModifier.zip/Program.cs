﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        int carCount = int.Parse(Console.ReadLine());
        List<Car> data = new List<Car>();
        for (int i = 0; i < carCount; i++)
        {
            string[] carArgs = Console.ReadLine().Split();
            Car car = new Car(carArgs);
            data.Add(car);           
        }
        string command = Console.ReadLine();
        switch (command)
        {
            case "fragile":
                data = data.Where(c => c.cargo.CargoType == command).Where(c => c.Tires[0].Any(e => e < 1)).ToList();
                break;
            case "flamable":
                data = data.Where(c => c.cargo.CargoType == command).Where(c => c.engine.EnginePower > 250).ToList();
                break;
            default:
                break;
        }
        foreach (var item in data)
        {
            Console.WriteLine($"{item.model.Name}");
        }
    } 
}

