﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        List<Department> departments = new List<Department>();
        
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            
            string[] tokens = Console.ReadLine().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string name = tokens[0];
            decimal salary = decimal.Parse(tokens[1]);
            string position = tokens[2];
            string department = tokens[3];
            string email;
            int age;
            try
            {               
                email = tokens[4].ToLower();
            }
            catch (Exception)
            {

                email = "n/a";
            }
            try
            {
                age = int.Parse(tokens[tokens.Length - 1]);
            }
            catch (Exception)
            {

                age = -1;
            }
            Employee employee = new Employee(name, salary, position, department, email, age);
            if (!departments.Any(d => d.Name == department))
            {
                Department dep = new Department(department);
                departments.Add(dep);
            }

            Department dept = departments.FirstOrDefault(d => d.Name == department);
            dept.AddEmployee(employee);
        }

        var highestAvrDep = departments.OrderByDescending(d => d.AverageSalary).First();
       
            Console.WriteLine($"Highest Average Salary: {highestAvrDep.Name}");
            foreach (var kvp in highestAvrDep.Employees.OrderByDescending(e => e.Salary))
            {
                Console.WriteLine($"{kvp.Name} {kvp.Salary:f2} {kvp.Email} {kvp.Age}");
            }
        
       
    }

    
}

