﻿public class Rectangle
{
    private string name;
    private int width;
    private int height;
    private int top;
    private int left;
    private int bottom;
    private int rigth;

    public Rectangle(string name, int width, int height, int top, int left)
    {
        this.name = name;
        this.width = width;
        this.height = height;
        this.top = top;
        this.left = left;
        this.bottom = top + height;
        this.rigth = left + width;
    }
    public Rectangle()
    {

    }
    public string Name
    {
        get { return name; }
        set { name = value; }
    }
    
    public void IntersectRectangles(Rectangle firstRect, Rectangle secondRect)
    {
        if ((firstRect.rigth < secondRect.left) || (secondRect.rigth < firstRect.left) || (firstRect.bottom < secondRect.top) || (secondRect.bottom < firstRect.top))
        {
            System.Console.WriteLine("false");
        }
        else
        {
            System.Console.WriteLine("true");
        }
       
    }

}