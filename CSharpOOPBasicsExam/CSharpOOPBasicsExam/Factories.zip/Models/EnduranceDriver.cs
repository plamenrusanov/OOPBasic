﻿

public class EnduranceDriver : Driver
{
    public EnduranceDriver(string name, Car Car)
        : base(name, Car, 1.5)
    {
    }
}
