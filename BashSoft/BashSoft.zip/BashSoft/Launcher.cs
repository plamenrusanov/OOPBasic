﻿using System;
using System.IO;

namespace BashSoft
{
    class Launcher
    {
        static void Main(string[] args)
        {
           
            InputReader.StartReadingCommands();
        }
    }
}
