﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IIdble
{
    string Id { get; }
}