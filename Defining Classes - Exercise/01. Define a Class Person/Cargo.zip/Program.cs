﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] nM = Console.ReadLine().Split(new[] { ' ' },StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
        int numberOfRectangles = nM[0];
        int numberOfChecks = nM[1];
        List<Rectangle> data = new List<Rectangle>();
        for (int i = 0; i < numberOfRectangles; i++)
        {
            string[] rectArgs = Console.ReadLine().Split(new[] { ' ' },StringSplitOptions.RemoveEmptyEntries);
            string name = rectArgs[0];
            int width = int.Parse(rectArgs[1]);
            int height = int.Parse(rectArgs[2]);
            int top = int.Parse(rectArgs[3]);
            int left = int.Parse(rectArgs[4]);
            Rectangle rectangle = new Rectangle(name, width, height, top, left);
            data.Add(rectangle);
        }

        for (int i = 0; i < numberOfChecks; i++)
        {
            string[] comparierNames = Console.ReadLine().Split();
            string first = comparierNames[0];
            string second = comparierNames[1];
            var firstRect = data.FirstOrDefault(r => r.Name == first);
            var secondRect = data.FirstOrDefault(r => r.Name == second);
            Rectangle rectangle = new Rectangle();
            rectangle.IntersectRectangles(firstRect, secondRect);
         
        }
    } 
}

