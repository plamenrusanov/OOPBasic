﻿public interface IHarvester : IIdble
{
    double EnergyRequirement { get; }
    double OreOutput { get; }
}