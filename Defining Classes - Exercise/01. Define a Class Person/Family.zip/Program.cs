﻿using System;

class Program
{
    static void Main()
    {
        var fam = new Family();
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            string[] args = Console.ReadLine().Split(' ');
            string name = args[0];
            int age = int.Parse(args[1]);
           
            fam.AddMember(new Person(name, age));
        }
        var oldPerson = fam.GetOldestMember();
        Console.WriteLine($"{oldPerson.Name} {oldPerson.Age}");
    }
}

