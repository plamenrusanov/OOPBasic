﻿public interface IProvider : IIdble
{
    double EnergyOutput { get; }
}