﻿using System;

class Program
{
    static void Main(string[] args)
    {
        var person = new Person();

    }
}

